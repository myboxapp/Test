/**
 * This package contains API of WorkplacePortalMobileService for Workplace Services Portal mobile
 * application, the Reservations part.
 */
package com.archibus.app.reservation.service.mobile;