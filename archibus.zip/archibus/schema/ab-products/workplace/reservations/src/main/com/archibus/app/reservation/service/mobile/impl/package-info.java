/**
 * This package contains API and implementation of WorkplacePortalReservationsMobileService for
 * Workplace Services Portal mobile application.
 */
package com.archibus.app.reservation.service.mobile.impl;