/**
 * Provides classes and interfaces for services for reservation module.  
 */
package com.archibus.app.reservation.service;