/**
 * Provides helpers used by reservations module service classes.  
 */
package com.archibus.app.reservation.service.helpers;